/**
 * Convierte una distancia Levenshtein en un score de 0 a 100.
 * Se compara la distancia contra la longitud de la palabra más larga
 * (esperada vs escuchada), ya que es la cantidad máxima de ediciones
 * posibles para llegar de una palabra a la otra.
 *
 * Si ambas palabras son idénticas, distancia = 0 → score = 100.
 * Si son completamente distintas, distancia ≈ longitud máxima → score ≈ 0.
 */
export function distanciaAScore(distancia: number, longitudMaxima: number): number {
  if (longitudMaxima === 0) return 100

  const proporcionDeError = distancia / longitudMaxima
  const score = (1 - proporcionDeError) * 100

  // Aseguramos el rango 0-100 y redondeamos a entero
  return Math.round(Math.max(0, Math.min(100, score)))
}

/**
 * Clasifica un score numérico en una categoría cualitativa,
 * usada para colorear la palabra en la UI.
 */
export function clasificarScore(score: number): 'bien' | 'regular' | 'mal' {
  if (score >= 70) return 'bien'
  if (score >= 50) return 'regular'
  return 'mal'
}

/**
 * Devuelve el mensaje corto asociado a un score, según las reglas de evaluación:
 *  90-100: "¡Perfecto!"
 *  70-89:  "¡Muy bien!"
 *  50-69:  "Casi, practica más"
 *  0-49:   "Necesita práctica"
 */
export function mensajePorScore(score: number): string {
  if (score >= 90) return '¡Perfecto!'
  if (score >= 70) return '¡Muy bien!'
  if (score >= 50) return 'Casi, practica más'
  return 'Necesita práctica'
}
