import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Nivel, ProgresoUsuario, RegistroEjercicio } from '../types/types'
import { obtenerEjerciciosDeNivel } from '../datos'

const VIDAS_INICIALES = 3
const SCORE_MINIMO_PARA_DESBLOQUEAR = 70
const PORCENTAJE_MINIMO_PARA_DESBLOQUEAR = 0.8

const progresoInicial: ProgresoUsuario = {
  nivelActual: 1,
  nivelesDesbloqueados: [1],
  vidasRestantes: VIDAS_INICIALES,
  ejercicioActualIndex: 0,
  historial: [],
}

/**
 * Calcula si un nivel cumple el criterio para desbloquear el siguiente:
 * al menos 80% de sus ejercicios completados con score >= 70.
 */
function calcularSiNivelEstaCompletado(nivel: Nivel, historial: RegistroEjercicio[]): boolean {
  const ejerciciosDelNivel = obtenerEjerciciosDeNivel(nivel)
  if (ejerciciosDelNivel.length === 0) return false

  const idsConBuenScore = new Set(
    historial
      .filter((registro) => registro.score >= SCORE_MINIMO_PARA_DESBLOQUEAR)
      .map((registro) => registro.ejercicioId),
  )

  const cantidadCompletados = ejerciciosDelNivel.filter((ejercicio) =>
    idsConBuenScore.has(ejercicio.id),
  ).length

  return cantidadCompletados / ejerciciosDelNivel.length >= PORCENTAJE_MINIMO_PARA_DESBLOQUEAR
}

interface ProgresoStore {
  progreso: ProgresoUsuario
  perderVida: () => void
  reiniciarVidas: () => void
  avanzarEjercicio: (ejercicioId: string, score: number) => void
  desbloquearNivel: (nivel: Nivel) => void
  seleccionarNivel: (nivel: Nivel) => void
}

/**
 * Store central de progreso del usuario. Persiste en localStorage vía el
 * middleware `persist` de Zustand (antes esto se hacía a mano con un
 * useEffect + localStorage.setItem en usarProgreso.ts).
 *
 * TODO_BACKEND: cuando haya API, reemplazar el storage de `persist` por
 * uno que sincronice contra el backend (o sacar `persist` y cargar/guardar
 * el progreso explícitamente con llamadas a la API).
 */
export const useProgresoStore = create<ProgresoStore>()(
  persist(
    (set) => ({
      progreso: progresoInicial,

      perderVida: () =>
        set((estado) => ({
          progreso: {
            ...estado.progreso,
            vidasRestantes: Math.max(0, estado.progreso.vidasRestantes - 1),
          },
        })),

      reiniciarVidas: () =>
        set((estado) => ({
          progreso: { ...estado.progreso, vidasRestantes: VIDAS_INICIALES },
        })),

      desbloquearNivel: (nivel) =>
        set((estado) => {
          if (estado.progreso.nivelesDesbloqueados.includes(nivel)) return estado
          return {
            progreso: {
              ...estado.progreso,
              nivelesDesbloqueados: [...estado.progreso.nivelesDesbloqueados, nivel].sort(),
            },
          }
        }),

      seleccionarNivel: (nivel) =>
        set((estado) => ({
          progreso: {
            ...estado.progreso,
            nivelActual: nivel,
            ejercicioActualIndex: 0,
            vidasRestantes: VIDAS_INICIALES,
          },
        })),

      /**
       * Registra el resultado de un ejercicio en el historial, avanza al
       * siguiente ejercicio del nivel, resetea las vidas y, si corresponde,
       * desbloquea el siguiente nivel.
       */
      avanzarEjercicio: (ejercicioId, score) =>
        set((estado) => {
          const actual = estado.progreso

          const nuevoRegistro: RegistroEjercicio = {
            ejercicioId,
            score,
            fecha: new Date().toISOString(),
            intentos: (actual.historial.filter((r) => r.ejercicioId === ejercicioId).length || 0) + 1,
          }

          const nuevoHistorial = [...actual.historial, nuevoRegistro]
          const ejerciciosDelNivel = obtenerEjerciciosDeNivel(actual.nivelActual)
          const siguienteIndex = actual.ejercicioActualIndex + 1
          const terminoElNivel = siguienteIndex >= ejerciciosDelNivel.length

          let nivelesDesbloqueados = actual.nivelesDesbloqueados
          if (terminoElNivel && calcularSiNivelEstaCompletado(actual.nivelActual, nuevoHistorial)) {
            const siguienteNivel = (actual.nivelActual + 1) as Nivel
            if (siguienteNivel <= 4 && !nivelesDesbloqueados.includes(siguienteNivel)) {
              nivelesDesbloqueados = [...nivelesDesbloqueados, siguienteNivel].sort()
            }
          }

          return {
            progreso: {
              ...actual,
              historial: nuevoHistorial,
              ejercicioActualIndex: terminoElNivel ? actual.ejercicioActualIndex : siguienteIndex,
              vidasRestantes: VIDAS_INICIALES,
              nivelesDesbloqueados,
            },
          }
        }),
    }),
    {
      name: 'pronunciacion-app:progreso',
      // Solo persistimos el campo `progreso`, no las funciones de acción.
      partialize: (estado) => ({ progreso: estado.progreso }),
    },
  ),
)

/**
 * Calcula el porcentaje de ejercicios completados (score >= 70) de un nivel.
 * Selector puro: no vive en el store para no recalcularse en cada set().
 */
export function porcentajeCompletadoDeNivel(nivel: Nivel, historial: RegistroEjercicio[]): number {
  const ejerciciosDelNivel = obtenerEjerciciosDeNivel(nivel)
  if (ejerciciosDelNivel.length === 0) return 0

  const idsCompletados = new Set(
    historial
      .filter((registro) => registro.score >= SCORE_MINIMO_PARA_DESBLOQUEAR)
      .map((registro) => registro.ejercicioId),
  )

  const cantidadCompletados = ejerciciosDelNivel.filter((ejercicio) =>
    idsCompletados.has(ejercicio.id),
  ).length

  return Math.round((cantidadCompletados / ejerciciosDelNivel.length) * 100)
}

/**
 * Calcula las estrellas obtenidas (0-3) según el score promedio de los
 * ejercicios completados del nivel: >=90 → 3, >=70 → 2, >=60 → 1.
 */
export function estrellasDeNivel(nivel: Nivel, historial: RegistroEjercicio[]): number {
  const ejerciciosDelNivel = obtenerEjerciciosDeNivel(nivel)
  const idsDelNivel = new Set(ejerciciosDelNivel.map((e) => e.id))

  const mejoresScores = new Map<string, number>()
  for (const registro of historial) {
    if (!idsDelNivel.has(registro.ejercicioId)) continue
    const mejorActual = mejoresScores.get(registro.ejercicioId) ?? 0
    mejoresScores.set(registro.ejercicioId, Math.max(mejorActual, registro.score))
  }

  if (mejoresScores.size === 0) return 0

  const scores = Array.from(mejoresScores.values())
  const promedio = scores.reduce((suma, s) => suma + s, 0) / scores.length

  if (promedio >= 90) return 3
  if (promedio >= 70) return 2
  if (promedio >= 60) return 1
  return 0
}
